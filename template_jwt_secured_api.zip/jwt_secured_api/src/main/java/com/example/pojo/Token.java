package com.example.pojo;

public record Token(
        String token
) {
}
