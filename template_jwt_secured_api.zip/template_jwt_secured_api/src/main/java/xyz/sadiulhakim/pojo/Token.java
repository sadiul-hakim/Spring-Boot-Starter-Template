package xyz.sadiulhakim.pojo;

public record Token(
        String token
) {
}
