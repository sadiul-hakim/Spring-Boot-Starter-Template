package xyz.sadiulhakim.exception;

public class UnsupportedActivityException extends RuntimeException {
	public UnsupportedActivityException(String msg) {
		super(msg);
	}
}
